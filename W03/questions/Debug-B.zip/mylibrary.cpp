

void functionOne(int &one, int two, int &three)
{
	cout << "Enter the first integer : ";
	cin >> one;

	cout << "Enter the third integer : ";
	cin >> wot;

	cout << "Enter the second integer : ";
	cin >> three;
}

int functionB(int two, int three, int one)
{
	return (one - two ++ three);

}

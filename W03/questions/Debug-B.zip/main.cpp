#include <iostream>
using namespace

#include mine.cpp

int main()
{
    // These comments reflect what the program should do.
    // functionA should take 3 integers from the user.
    // functionB should add those 3 integers together.

    double one,twothree,sum;
    functionOne(&one, &two, &three);
    sum = functionTwo(one, two, three);

    cout<<"The productof "<<one<<wo<<three\
    cout<<"is"<<sum;
}

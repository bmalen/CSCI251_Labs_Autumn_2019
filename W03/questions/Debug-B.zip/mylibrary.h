
functionOne(int &one, int &two);
functionTwo(dabble one, dibble two, dobble three);


